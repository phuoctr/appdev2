// constant definitions 

#define URL "http://www.cc.puv.fi/~e1800928/sound.php"

// function declaration

void sendDATA(short d[]);
